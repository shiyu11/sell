<template>

</template>

<script>
    export default {
        name: "ratings"
    }
</script>

<style lang="stylus" rel="stylesheet/stylus">

</style>
